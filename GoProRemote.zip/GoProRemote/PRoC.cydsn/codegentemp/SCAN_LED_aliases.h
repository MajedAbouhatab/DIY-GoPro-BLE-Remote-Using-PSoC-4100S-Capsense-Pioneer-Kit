/*******************************************************************************
* File Name: SCAN_LED.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SCAN_LED_ALIASES_H) /* Pins SCAN_LED_ALIASES_H */
#define CY_PINS_SCAN_LED_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define SCAN_LED_0			(SCAN_LED__0__PC)
#define SCAN_LED_0_PS		(SCAN_LED__0__PS)
#define SCAN_LED_0_PC		(SCAN_LED__0__PC)
#define SCAN_LED_0_DR		(SCAN_LED__0__DR)
#define SCAN_LED_0_SHIFT	(SCAN_LED__0__SHIFT)
#define SCAN_LED_0_INTR	((uint16)((uint16)0x0003u << (SCAN_LED__0__SHIFT*2u)))

#define SCAN_LED_INTR_ALL	 ((uint16)(SCAN_LED_0_INTR))


#endif /* End Pins SCAN_LED_ALIASES_H */


/* [] END OF FILE */
