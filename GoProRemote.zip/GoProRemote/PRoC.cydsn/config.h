/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "project.h"	
	
#define LOW_POWER_MODE

#define LED_INDICATION
	
#endif	/* _CONFIG_H_ */

